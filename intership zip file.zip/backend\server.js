const express = require('express');
const cors = require('cors');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '.env') });

const { testConnection } = require('./db');
const devicesRouter = require('./routes/devices');
const usersRouter = require('./routes/users');
const alertsRouter = require('./routes/alerts');
const sensorsRouter = require('./routes/sensors');
const dashboardRouter = require('./routes/dashboard');
const settingsRouter = require('./routes/settings');
const errorHandler = require('./middleware/errorHandler');

const app = express();
const PORT = process.env.PORT || 5000;

// CORS configuration - Allow designated React clients dynamically
const allowedOrigins = [
  'http://localhost:5173',
  'http://localhost:5174',
  'http://localhost:3000',
  process.env.FRONTEND_URL
].filter(Boolean);

const corsOptions = {
  origin: function (origin, callback) {
    const isVercel = origin && (origin.endsWith('.vercel.app') || origin.endsWith('.now.sh'));
    if (!origin || allowedOrigins.includes(origin) || isVercel || process.env.NODE_ENV !== 'production') {
      callback(null, true);
    } else {
      callback(new Error('Not allowed by CORS'));
    }
  },
  credentials: true,
  optionsSuccessStatus: 200
};
app.use(cors(corsOptions));

// Request payload parsing middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Request logging middleware with payload output
app.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
  if (req.method !== 'GET' && req.body && Object.keys(req.body).length > 0) {
    console.log('Request Payload:', JSON.stringify(req.body, null, 2));
  }
  next();
});

// Health check endpoint
app.get(['/health', '/api/health'], (req, res) => {
  res.status(200).json({
    status: 'healthy',
    timestamp: new Date()
  });
});

// Mount Routes
app.use('/api/devices', devicesRouter);
app.use('/api/users', usersRouter);
app.use('/api/alerts', alertsRouter);
app.use('/api/sensors', sensorsRouter);
app.use('/api/dashboard', dashboardRouter);
app.use('/api/settings', settingsRouter);

// Test Email Endpoint
const { sendTestEmail } = require('./services/emailService');
app.post('/api/test-email', async (req, res) => {
  try {
    const info = await sendTestEmail();
    res.status(200).json({
      success: true,
      message: 'Test email sent successfully.',
      accepted: info.accepted,
      rejected: info.rejected,
      response: info.response,
      messageId: info.messageId
    });
  } catch (error) {
    console.error('TestEmail Route Error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to send test email.',
      error: error.message
    });
  }
});

// 404 Route handling
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: `Endpoint ${req.method} ${req.originalUrl} not found.`
  });
});

// Global error handling middleware
app.use(errorHandler);

// Database verification and Server startup
async function startServer() {
  try {
    // 1. Verify database connection
    await testConnection();

    // 2. Initialize settings schema and seed admin user
    const settingsService = require('./services/settingsService');
    await settingsService.initSettingsTable();
    await settingsService.seedDefaultSettings();
    console.log('Database initialized successfully.');
  } catch (error) {
    console.warn('Database initialization failed. Server will start but database features may be unavailable:', error.message);
  }

  // 3. Start server (avoid app.listen in serverless env)
  if (!process.env.VERCEL) {
    app.listen(PORT, () => {
      console.log(`Server Running on Port ${PORT}`);
    });
  }
}

startServer();

module.exports = app;
