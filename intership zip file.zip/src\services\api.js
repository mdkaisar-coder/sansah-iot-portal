const getBaseUrl = () => {
  if (typeof window !== 'undefined' && window.location.hostname !== 'localhost' && window.location.hostname !== '127.0.0.1') {
    return '/api';
  }
  if (import.meta.env.VITE_API_URL) {
    return import.meta.env.VITE_API_URL;
  }
  return 'http://localhost:5000/api';
};

const BASE_URL = getBaseUrl();

/**
 * Standardized fetch API helper that handles errors and parsing uniformly.
 */
async function apiFetch(endpoint, options = {}) {
  const url = `${BASE_URL}${endpoint}`;
  const headers = {
    'Content-Type': 'application/json',
    ...(options.headers || {})
  };

  const config = {
    ...options,
    headers
  };

  try {
    const res = await fetch(url, config);
    
    // Attempt parsing JSON
    let data = null;
    const contentType = res.headers.get('content-type');
    if (contentType && contentType.includes('application/json')) {
      data = await res.json();
    } else {
      data = { success: res.ok, message: await res.text() };
    }

    if (!res.ok) {
      throw new Error(data.message || `HTTP error! status: ${res.status}`);
    }

    return data;
  } catch (error) {
    console.error(`API Fetch Error [${url}]:`, error);
    throw error;
  }
}

export const api = {
  // Dashboard Stats
  fetchDashboardStats: () => apiFetch('/dashboard/stats'),

  // Devices
  fetchDevices: () => apiFetch('/devices'),
  fetchDeviceById: (id) => apiFetch(`/devices/${id}`),
  registerDevice: (payload) => apiFetch('/devices', {
    method: 'POST',
    body: JSON.stringify(payload)
  }),
  updateDevice: (id, payload) => apiFetch(`/devices/${id}`, {
    method: 'PUT',
    body: JSON.stringify(payload)
  }),
  deleteDevice: (id) => apiFetch(`/devices/${id}`, {
    method: 'DELETE'
  }),

  // Sensors
  fetchSensors: (deviceId) => apiFetch(`/sensors?deviceId=${deviceId}`),
  logSensorReading: (payload) => apiFetch('/sensors', {
    method: 'POST',
    body: JSON.stringify(payload)
  }),

  // Alerts
  fetchAlerts: ({ status, severity, device_id, page = 1, limit = 10 } = {}) => {
    let query = `/alerts?page=${page}&limit=${limit}`;
    if (status && status !== 'All') query += `&status=${status}`;
    if (severity && severity !== 'All') query += `&severity=${severity}`;
    if (device_id) query += `&device_id=${device_id}`;
    return apiFetch(query);
  },
  fetchAlertStats: () => apiFetch('/alerts/stats'),
  acknowledgeAlert: (id) => apiFetch(`/alerts/${id}/acknowledge`, {
    method: 'PUT'
  }),
  resolveAlert: (id) => apiFetch(`/alerts/${id}/resolve`, {
    method: 'PUT'
  }),
  loginUser: (email, password) => apiFetch('/users/login', {
    method: 'POST',
    body: JSON.stringify({ email, password })
  }),
  triggerTestSpike: (deviceId) => apiFetch(`/devices/${deviceId}/test-spike`, {
    method: 'POST'
  }),
  fetchSettings: () => apiFetch('/settings'),
  updateAdminSettings: (payload) => apiFetch('/settings/admin', {
    method: 'PUT',
    body: JSON.stringify(payload)
  }),
  updateEmailSettings: (payload) => apiFetch('/settings/email', {
    method: 'PUT',
    body: JSON.stringify(payload)
  }),
  sendSettingsTestEmail: (payload) => apiFetch('/settings/test-email', {
    method: 'POST',
    body: JSON.stringify(payload)
  }),
  fetchSystemStatus: () => apiFetch('/settings/system-status')
};
