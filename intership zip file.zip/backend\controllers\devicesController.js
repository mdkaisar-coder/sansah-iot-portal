const devicesService = require('../services/devicesService');

// @desc    Get all devices
// @route   GET /api/devices
const getDevices = async (req, res, next) => {
  try {
    const devices = await devicesService.getAllDevices();
    res.status(200).json({
      success: true,
      count: devices.length,
      data: devices
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get a single device by ID
// @route   GET /api/devices/:id
const getDeviceById = async (req, res, next) => {
  const { id } = req.params;
  try {
    const device = await devicesService.getDeviceById(id);
    if (!device) {
      return res.status(404).json({
        success: false,
        message: `Device with ID ${id} not found.`
      });
    }
    res.status(200).json({
      success: true,
      data: device
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Create a new device
// @route   POST /api/devices
const createDevice = async (req, res, next) => {
  const { device_code } = req.body;
  try {
    // Validate device code uniqueness
    const existing = await devicesService.getDeviceByCode(device_code);
    if (existing) {
      return res.status(400).json({
        success: false,
        message: `A device with code '${device_code}' already exists.`
      });
    }

    const device = await devicesService.createDevice(req.body);
    res.status(201).json({
      success: true,
      message: 'Device created successfully.',
      data: device
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update a device by ID
// @route   PUT /api/devices/:id
const updateDevice = async (req, res, next) => {
  const { id } = req.params;
  const { device_code } = req.body;

  try {
    // Verify device exists
    const existing = await devicesService.getDeviceById(id);
    if (!existing) {
      return res.status(404).json({
        success: false,
        message: `Device with ID ${id} not found.`
      });
    }

    // Check device code collision if changed
    if (device_code) {
      const collision = await devicesService.checkDeviceCodeCollision(device_code, id);
      if (collision) {
        return res.status(400).json({
          success: false,
          message: `Device code '${device_code}' is already assigned to another device.`
        });
      }
    }

    const device = await devicesService.updateDevice(id, req.body);
    res.status(200).json({
      success: true,
      message: 'Device updated successfully.',
      data: device
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete a device by ID
// @route   DELETE /api/devices/:id
const deleteDevice = async (req, res, next) => {
  const { id } = req.params;
  try {
    const success = await devicesService.deleteDevice(id);
    if (!success) {
      return res.status(404).json({
        success: false,
        message: `Device with ID ${id} not found.`
      });
    }
    res.status(200).json({
      success: true,
      message: `Device with ID ${id} has been deleted.`
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Force telemetry critical values spike beyond thresholds for testing
// @route   POST /api/devices/:id/test-spike
const triggerTestSpike = async (req, res, next) => {
  const { id } = req.params;
  try {
    const device = await devicesService.getDeviceById(id);
    if (!device) {
      return res.status(404).json({
        success: false,
        message: `Device with ID ${id} not found.`
      });
    }

    // Force telemetry values beyond thresholds
    // Temperature = 55, Battery = 5, Signal Strength = 10
    const now = new Date();
    const testTelemetry = {
      'Temperature': 55.0,
      'Battery': 5.0,
      'Signal Strength': 10.0
    };

    // Category specific telemetry spiked checks
    if (device.sensor_type === 'Smoke Sensor') {
      testTelemetry['Smoke Level'] = 85.0;
    } else if (device.sensor_type === 'Gas Sensor') {
      testTelemetry['Gas Concentration'] = 850.0;
    } else if (device.sensor_type === 'Water Level Sensor') {
      testTelemetry['Water Level'] = 5.0;
    } else if (device.sensor_type === 'Air Quality Sensor') {
      testTelemetry['AQI'] = 220;
    }

    const { pool } = require('../db');
    const { checkAndCreateAlerts } = require('../services/telemetryService');

    // Insert spiked readings into database
    const insertValues = [];
    Object.entries(testTelemetry).forEach(([metricName, metricVal]) => {
      insertValues.push([device.id, metricName, String(metricVal), now]);
    });

    await pool.query(
      'INSERT INTO sensor_data (device_id, sensor_name, sensor_value, recorded_at) VALUES ?',
      [insertValues]
    );

    // Run rules logic to create active alert and update device status
    await checkAndCreateAlerts(device.id, testTelemetry);

    // Fetch the updated device status
    const updatedDevice = await devicesService.getDeviceById(id);

    res.status(200).json({
      success: true,
      message: 'Telemetry critical spike forced successfully.',
      data: {
        deviceStatus: updatedDevice.status,
        metrics: testTelemetry
      }
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getDevices,
  getDeviceById,
  createDevice,
  updateDevice,
  deleteDevice,
  triggerTestSpike
};
