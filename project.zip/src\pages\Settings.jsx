import { User, Bell, Lock, Shield } from 'lucide-react';
import FormInput from '../components/FormInput';

export default function Settings() {
  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div>
        <h1 className="text-2xl font-bold text-text">Settings</h1>
        <p className="text-muted text-sm mt-1">Manage your account preferences and security.</p>
      </div>

      <div className="space-y-6">
        {/* Profile Section */}
        <div className="bg-card border border-border rounded-xl p-6">
          <div className="flex items-center space-x-3 mb-6 border-b border-border pb-4">
            <User className="w-5 h-5 text-primary" />
            <h2 className="text-lg font-semibold text-text">Profile Information</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <FormInput label="Full Name" defaultValue="Admin User" />
            <FormInput label="Email Address" type="email" defaultValue="admin@iotportal.local" />
            <FormInput label="Role" defaultValue="Administrator" disabled />
            <FormInput label="Department" defaultValue="IT Operations" />
          </div>
          <div className="mt-6 flex justify-end">
            <button className="px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary/90 rounded-md transition-colors">
              Save Changes
            </button>
          </div>
        </div>

        {/* Notification Settings */}
        <div className="bg-card border border-border rounded-xl p-6">
          <div className="flex items-center space-x-3 mb-6 border-b border-border pb-4">
            <Bell className="w-5 h-5 text-primary" />
            <h2 className="text-lg font-semibold text-text">Notification Preferences</h2>
          </div>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-text">Email Alerts</p>
                <p className="text-xs text-muted">Receive critical system alerts via email.</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" defaultChecked />
                <div className="w-11 h-6 bg-secondary peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
              </label>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-text">Weekly Reports</p>
                <p className="text-xs text-muted">Get a weekly summary of device performance.</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" />
                <div className="w-11 h-6 bg-secondary peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
              </label>
            </div>
          </div>
        </div>

        {/* Security Settings */}
        <div className="bg-card border border-border rounded-xl p-6">
          <div className="flex items-center space-x-3 mb-6 border-b border-border pb-4">
            <Shield className="w-5 h-5 text-primary" />
            <h2 className="text-lg font-semibold text-text">Security Settings</h2>
          </div>
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormInput label="Current Password" type="password" placeholder="••••••••" />
              <FormInput label="New Password" type="password" placeholder="••••••••" />
            </div>
            <div className="mt-4">
              <button className="px-4 py-2 text-sm font-medium text-text bg-secondary hover:bg-secondary/80 rounded-md transition-colors">
                Update Password
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
