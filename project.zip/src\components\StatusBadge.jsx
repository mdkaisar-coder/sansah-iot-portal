import clsx from 'clsx';

export default function StatusBadge({ status }) {
  const isOnline = status === 'Online' || status === 'Resolved';
  const isWarning = status === 'Medium' || status === 'High';
  const isCritical = status === 'Offline' || status === 'Critical' || status === 'Active';

  return (
    <span className={clsx(
      "px-2.5 py-0.5 rounded-full text-xs font-medium border",
      isOnline && "bg-success/10 text-success border-success/20",
      isWarning && "bg-warning/10 text-warning border-warning/20",
      isCritical && "bg-danger/10 text-danger border-danger/20",
      !isOnline && !isWarning && !isCritical && "bg-muted/10 text-muted border-muted/20"
    )}>
      {status}
    </span>
  );
}
