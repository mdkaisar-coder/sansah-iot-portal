const nodemailer = require('nodemailer');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '../.env') });

let transporter = null;

function getTransporter() {
  if (transporter) return transporter;

  const user = process.env.EMAIL_USER;
  const pass = process.env.EMAIL_PASS;
  const adminEmail = process.env.ADMIN_EMAIL;

  console.log(`[Email Service Startup] EMAIL_USER is loaded: ${user ? 'YES (' + user + ')' : 'NO'}`);
  console.log(`[Email Service Startup] ADMIN_EMAIL is loaded: ${adminEmail ? 'YES (' + adminEmail + ')' : 'NO'}`);
  console.log(`[Email Service Startup] EMAIL_PASS is loaded: ${pass ? 'YES (Confidential)' : 'NO'}`);

  if (user && pass) {
    console.log(`EmailService: Initializing Gmail SMTP transport with user: ${user}`);
    transporter = nodemailer.createTransport({
      service: 'gmail',
      host: 'smtp.gmail.com',
      port: 465,
      secure: true, // SSL/TLS
      auth: {
        user,
        pass
      }
    });

    console.log('EmailService: Initiating transporter connection verification...');
    transporter.verify((err, success) => {
      if (err) {
        console.error('❌ EmailService Transporter Verification FAILED:', err.message);
      } else {
        console.log('✅ EmailService Transporter Verification SUCCESSFUL');
      }
    });

    return transporter;
  } else {
    console.warn('EmailService: EMAIL_USER or EMAIL_PASS not set in environment. Falling back to Console Logger.');
    transporter = {
      sendMail: async (mailOptions) => {
        console.log('\n--- EMAIL TRANSMISSION FALLBACK ---');
        console.log(`To: ${mailOptions.to}`);
        console.log(`Subject: ${mailOptions.subject}`);
        console.log('Body (HTML Preview):');
        console.log(mailOptions.html.replace(/<[^>]*>/g, ' ').substring(0, 500) + '...');
        console.log('-----------------------------------\n');
        return { messageId: 'console-logger-' + Date.now() };
      }
    };
    return transporter;
  }
}

/**
 * Sends alert notification email to Client and Admin
 * @param {Object} device - Device DB record details
 * @param {Object} alert - Alert details (message, severity, metric_name, metric_value, threshold_value)
 * @returns {Promise<boolean>} - True if email sent successfully, false otherwise
 */
async function sendAlertEmail(device, alert) {
  try {
    const activeTransporter = getTransporter();
    const adminEmail = process.env.ADMIN_EMAIL;
    console.log(`EmailService: Building recipient list for device ${device.device_code}...`);
    console.log(`EmailService: - Device alert_enabled: ${device.alert_enabled}`);
    console.log(`EmailService: - Client Email: ${device.client_email}`);
    console.log(`EmailService: - Admin Email: ${adminEmail}`);
    
    // Build email recipient list
    const recipients = [];
    
    // Client email: check if alert_enabled is true
    if (device.alert_enabled && device.client_email) {
      recipients.push(device.client_email);
    }
    
    // Admin email: check if ADMIN_EMAIL exists
    if (adminEmail) {
      recipients.push(adminEmail);
    }

    console.log(`EmailService: Final recipients list: ${recipients.join(', ')}`);

    if (recipients.length === 0) {
      console.log(`EmailService: No recipients configured or alert_enabled is false for device ${device.device_code}. Email skipped.`);
      return false;
    }

    const severityColorMap = {
      'Critical': '#ef4444', // red
      'High': '#f97316',     // orange
      'Medium': '#eab308',   // yellow
      'Low': '#3b82f6'       // blue
    };
    const severityColor = severityColorMap[alert.severity] || '#6b7280';
    const severityLabel = alert.severity ? alert.severity.toUpperCase() : 'WARNING';

    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>IoT Device Alert</title>
        <style>
          body {
            font-family: Arial, sans-serif;
            background-color: #f4f5f7;
            margin: 0;
            padding: 20px;
          }
          .container {
            max-width: 600px;
            background-color: #ffffff;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.08);
            border: 1px solid #e2e8f0;
            margin: 0 auto;
          }
          .header {
            background-color: ${severityColor};
            color: #ffffff;
            padding: 20px;
            text-align: center;
          }
          .header h2 {
            margin: 0;
            font-size: 20px;
            text-transform: uppercase;
            letter-spacing: 1px;
          }
          .content {
            padding: 25px;
          }
          .alert-box {
            background-color: #fffaf0;
            border-left: 4px solid ${severityColor};
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
          }
          .alert-box p {
            margin: 0;
            font-size: 15px;
            font-weight: bold;
            color: #2d3748;
          }
          table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
          }
          td {
            padding: 10px;
            border-bottom: 1px solid #edf2f7;
            font-size: 14px;
          }
          .label {
            font-weight: bold;
            color: #4a5568;
            width: 40%;
          }
          .value {
            color: #2d3748;
          }
          .footer {
            background-color: #edf2f7;
            color: #718096;
            text-align: center;
            padding: 15px;
            font-size: 13px;
            font-weight: bold;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h2>🚨 IoT Device Alert - ${severityLabel}</h2>
          </div>
          <div class="content">
            <div class="alert-box">
              <p>${alert.message}</p>
            </div>
            
            <table>
              <tr>
                <td class="label">Client Name</td>
                <td class="value">${device.client_name || 'N/A'}</td>
              </tr>
              <tr>
                <td class="label">Project Name</td>
                <td class="value">${device.project_name || 'N/A'}</td>
              </tr>
              <tr>
                <td class="label">Device Name</td>
                <td class="value">${device.device_name}</td>
              </tr>
              <tr>
                <td class="label">Device ID</td>
                <td class="value">${device.device_code}</td>
              </tr>
              <tr>
                <td class="label">Sensor Category</td>
                <td class="value">${device.sensor_type || 'N/A'}</td>
              </tr>
              <tr>
                <td class="label">Metric Name</td>
                <td class="value">${alert.metric_name}</td>
              </tr>
              <tr>
                <td class="label">Current Value</td>
                <td class="value" style="color: ${severityColor}; font-weight: bold;">${alert.metric_value}</td>
              </tr>
              <tr>
                <td class="label">Threshold Value</td>
                <td class="value">${alert.threshold_value}</td>
              </tr>
              <tr>
                <td class="label">Severity</td>
                <td class="value" style="color: ${severityColor}; font-weight: bold;">${alert.severity}</td>
              </tr>
              <tr>
                <td class="label">Timestamp</td>
                <td class="value">${new Date().toLocaleString()}</td>
              </tr>
            </table>
          </div>
          <div class="footer">
            IoT Monitoring System
          </div>
        </div>
      </body>
      </html>
    `;

    const mailOptions = {
      from: `"IoT Monitoring System" <${process.env.EMAIL_USER || 'no-reply@iot.com'}>`,
      to: recipients.join(', '),
      subject: `🚨 IoT Device Alert - ${device.device_name}`,
      html: htmlContent
    };

    console.log(`EmailService: Calling activeTransporter.sendMail()...`);
    const info = await activeTransporter.sendMail(mailOptions);
    console.log(`EmailService: transporter.sendMail() execution completed successfully.`);
    console.log(`EmailService: Nodemailer response:`, JSON.stringify({
      accepted: info.accepted,
      rejected: info.rejected,
      response: info.response,
      messageId: info.messageId
    }, null, 2));
    return true;
  } catch (err) {
    console.error('EmailService error: Failed to send email alert:', err.message);
    return false;
  }
}

/**
 * Sends a test email to the ADMIN_EMAIL to verify SMTP configuration
 * @returns {Promise<Object>}
 */
async function sendTestEmail() {
  const adminEmail = process.env.ADMIN_EMAIL;
  if (!adminEmail) {
    throw new Error('ADMIN_EMAIL is not set in environment.');
  }

  const activeTransporter = getTransporter();
  const mailOptions = {
    from: `"IoT Monitoring System - Test" <${process.env.EMAIL_USER || 'no-reply@iot.com'}>`,
    to: adminEmail,
    subject: '🧪 IoT Monitoring System - SMTP Test Email',
    html: `
      <div style="font-family: Arial, sans-serif; padding: 20px; border: 1px solid #e2e8f0; border-radius: 8px; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #3b82f6; border-bottom: 1px solid #edf2f7; padding-bottom: 10px;">🧪 SMTP Connection Test Successful</h2>
        <p>This test email confirms that the Nodemailer transporter is successfully configured and authenticated via Gmail SMTP.</p>
        <table style="width: 100%; border-collapse: collapse; margin-top: 15px;">
          <tr>
            <td style="padding: 6px 0; font-weight: bold; color: #4a5568;">SMTP User:</td>
            <td style="padding: 6px 0; color: #2d3748;">${process.env.EMAIL_USER}</td>
          </tr>
          <tr>
            <td style="padding: 6px 0; font-weight: bold; color: #4a5568;">Recipient:</td>
            <td style="padding: 6px 0; color: #2d3748;">${adminEmail}</td>
          </tr>
          <tr>
            <td style="padding: 6px 0; font-weight: bold; color: #4a5568;">Timestamp:</td>
            <td style="padding: 6px 0; color: #2d3748;">${new Date().toLocaleString()}</td>
          </tr>
        </table>
      </div>
    `
  };

  console.log(`EmailService: Dispatching SMTP test email to: ${adminEmail}`);
  const info = await activeTransporter.sendMail(mailOptions);
  console.log(`EmailService: SMTP test email sent. Message ID: ${info.messageId}`);
  return info;
}

module.exports = {
  sendAlertEmail,
  sendTestEmail
};
