import { useEffect, useState } from 'react';
import { Cpu, Server, AlertTriangle, Activity } from 'lucide-react';
import { Link } from 'react-router-dom';
import StatCard from '../components/StatCard';
import AlertCard from '../components/AlertCard';
import TableComponent from '../components/TableComponent';
import StatusBadge from '../components/StatusBadge';

export default function Dashboard() {
  const [stats, setStats] = useState({ 
    totalDevices: 0, 
    onlineDevices: 0, 
    offlineDevices: 0, 
    totalAlerts: 0,
    categoryBreakdown: {}
  });
  const [devices, setDevices] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        setLoading(true);
        setError('');

        // 1. Fetch Stats
        const statsRes = await fetch('http://localhost:5000/api/dashboard/stats');
        const statsData = await statsRes.json();

        // 2. Fetch Devices
        const devicesRes = await fetch('http://localhost:5000/api/devices');
        const devicesData = await devicesRes.json();

        // 3. Fetch Alerts
        const alertsRes = await fetch('http://localhost:5000/api/alerts');
        const alertsData = await alertsRes.json();

        if (statsRes.ok) {
          setStats(statsData);
        }
        if (devicesRes.ok && devicesData.success) {
          const mappedDevices = devicesData.data.map(d => ({
            id: d.id,
            device_code: d.device_code,
            name: d.device_name,
            protocol: d.protocol,
            client_name: d.client_name || 'N/A',
            project: d.project_name || 'N/A',
            status: d.status
          }));
          setDevices(mappedDevices);
        }
        if (alertsRes.ok && alertsData.success) {
          const mappedAlerts = alertsData.data.map(a => ({
            id: a.id,
            severity: a.severity || 'Warning',
            message: a.message,
            deviceName: a.device_name || 'Unknown Device',
            date: a.created_at,
            status: a.status
          }));
          setAlerts(mappedAlerts);
        }
      } catch (err) {
        console.error('Error fetching dashboard data:', err);
        setError('Failed to load dashboard data. Is the backend running?');
      } finally {
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-danger/10 border border-danger text-danger p-4 rounded-lg text-center font-medium">
        {error}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-text">Dashboard Overview</h1>
        <p className="text-muted text-sm mt-1">Welcome back, here's what's happening today.</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          title="Total Devices" 
          value={stats.totalDevices} 
          icon={Cpu} 
          colorClass="bg-primary/20 text-primary" 
        />
        <StatCard 
          title="Online Devices" 
          value={stats.onlineDevices} 
          icon={Activity} 
          colorClass="bg-success/20 text-success" 
        />
        <StatCard 
          title="Offline Devices" 
          value={stats.offlineDevices} 
          icon={Server} 
          colorClass="bg-danger/20 text-danger" 
        />
        <StatCard 
          title="Active Alerts" 
          value={stats.totalAlerts} 
          icon={AlertTriangle} 
          colorClass="bg-warning/20 text-warning" 
        />
      </div>

      {/* Device Categories Breakdown */}
      {stats.categoryBreakdown && Object.keys(stats.categoryBreakdown).length > 0 && (
        <div className="bg-card border border-border rounded-xl p-6">
          <h2 className="text-sm font-semibold text-text uppercase tracking-wider mb-4">Device Categories Summary</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {Object.entries(stats.categoryBreakdown).map(([category, count]) => (
              <div key={category} className="bg-secondary/20 border border-border/50 rounded-lg p-3 flex flex-col justify-between hover:border-primary/30 transition-colors">
                <span className="text-xs text-muted font-medium truncate" title={category}>{category}</span>
                <span className="text-xl font-bold text-text mt-1">{count}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Devices Table */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex justify-between items-end">
            <h2 className="text-lg font-semibold text-text">Recent Devices</h2>
            <Link to="/devices" className="text-sm text-primary hover:underline">View All</Link>
          </div>
          <TableComponent headers={['Device Name', 'Protocol', 'Client Name', 'Project', 'Status', 'Action']}>
            {devices.slice(0, 5).map((device) => (
              <tr key={device.id} className="hover:bg-secondary/50 transition-colors">
                <td className="px-6 py-4">
                  <div className="font-medium text-text">{device.name}</div>
                  <div className="text-xs text-muted font-mono">{device.device_code}</div>
                </td>
                <td className="px-6 py-4 text-text">{device.protocol}</td>
                <td className="px-6 py-4 text-text">{device.client_name}</td>
                <td className="px-6 py-4 text-text">{device.project}</td>
                <td className="px-6 py-4">
                  <StatusBadge status={device.status} />
                </td>
                <td className="px-6 py-4">
                  <Link to={`/devices/${device.id}`} className="font-medium text-primary hover:underline">Details</Link>
                </td>
              </tr>
            ))}
            {devices.length === 0 && (
              <tr>
                <td colSpan="6" className="px-6 py-4 text-center text-muted">No devices registered.</td>
              </tr>
            )}
          </TableComponent>
        </div>

        {/* Recent Alerts List */}
        <div className="space-y-4">
          <div className="flex justify-between items-end">
            <h2 className="text-lg font-semibold text-text">Recent Alerts</h2>
            <Link to="/alerts" className="text-sm text-primary hover:underline">View All</Link>
          </div>
          <div className="space-y-3">
            {alerts.slice(0, 4).map((alert) => (
              <AlertCard key={alert.id} alert={alert} />
            ))}
            {alerts.length === 0 && (
              <div className="text-center py-8 text-muted bg-card border border-border rounded-xl">
                No active alerts.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
