const { pool } = require('../db');

// @desc    Get all devices
// @route   GET /api/devices
const getDevices = async (req, res, next) => {
  try {
    const [devices] = await pool.query('SELECT * FROM devices');
    res.status(200).json({
      success: true,
      count: devices.length,
      data: devices
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get a single device by ID
// @route   GET /api/devices/:id
const getDeviceById = async (req, res, next) => {
  const { id } = req.params;
  try {
    const [devices] = await pool.query('SELECT * FROM devices WHERE id = ?', [id]);
    if (devices.length === 0) {
      return res.status(404).json({
        success: false,
        message: `Device with ID ${id} not found.`
      });
    }
    res.status(200).json({
      success: true,
      data: devices[0]
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Create a new device
// @route   POST /api/devices
const createDevice = async (req, res, next) => {
  const { 
    device_name, 
    device_code, 
    device_type, 
    protocol, 
    project_name, 
    location, 
    status, 
    sensor_type,
    client_name,
    client_email,
    client_phone,
    alert_enabled
  } = req.body;

  try {
    // Validate device code uniqueness
    const [existing] = await pool.query('SELECT id FROM devices WHERE device_code = ?', [device_code]);
    if (existing.length > 0) {
      return res.status(400).json({
        success: false,
        message: `A device with code '${device_code}' already exists.`
      });
    }

    const [result] = await pool.query(
      'INSERT INTO devices (device_name, device_code, device_type, protocol, project_name, location, status, sensor_type, client_name, client_email, client_phone, alert_enabled) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      [
        device_name,
        device_code,
        device_type,
        protocol,
        project_name || null,
        location || null,
        status || 'Inactive',
        sensor_type || null,
        client_name || null,
        client_email || null,
        client_phone || null,
        alert_enabled !== undefined ? alert_enabled : true
      ]
    );

    res.status(201).json({
      success: true,
      message: 'Device created successfully.',
      data: {
        id: result.insertId,
        device_name,
        device_code,
        device_type,
        protocol,
        project_name: project_name || null,
        location: location || null,
        status: status || 'Inactive',
        sensor_type: sensor_type || null,
        client_name: client_name || null,
        client_email: client_email || null,
        client_phone: client_phone || null,
        alert_enabled: alert_enabled !== undefined ? alert_enabled : true
      }
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update a device by ID
// @route   PUT /api/devices/:id
const updateDevice = async (req, res, next) => {
  const { id } = req.params;
  const { 
    device_name, 
    device_code, 
    device_type, 
    protocol, 
    project_name, 
    location, 
    status, 
    sensor_type,
    client_name,
    client_email,
    client_phone,
    alert_enabled
  } = req.body;

  try {
    // Verify device exists
    const [existing] = await pool.query('SELECT id FROM devices WHERE id = ?', [id]);
    if (existing.length === 0) {
      return res.status(404).json({
        success: false,
        message: `Device with ID ${id} not found.`
      });
    }

    // Check device code collision if changed
    if (device_code) {
      const [duplicate] = await pool.query('SELECT id FROM devices WHERE device_code = ? AND id != ?', [device_code, id]);
      if (duplicate.length > 0) {
        return res.status(400).json({
          success: false,
          message: `Device code '${device_code}' is already assigned to another device.`
        });
      }
    }

    // Perform database update
    await pool.query(
      `UPDATE devices SET 
        device_name = COALESCE(?, device_name),
        device_code = COALESCE(?, device_code),
        device_type = COALESCE(?, device_type),
        protocol = COALESCE(?, protocol),
        project_name = COALESCE(?, project_name),
        location = COALESCE(?, location),
        status = COALESCE(?, status),
        sensor_type = COALESCE(?, sensor_type),
        client_name = COALESCE(?, client_name),
        client_email = COALESCE(?, client_email),
        client_phone = COALESCE(?, client_phone),
        alert_enabled = COALESCE(?, alert_enabled)
       WHERE id = ?`,
      [
        device_name || null,
        device_code || null,
        device_type || null,
        protocol || null,
        project_name || null,
        location || null,
        status || null,
        sensor_type || null,
        client_name || null,
        client_email || null,
        client_phone || null,
        alert_enabled !== undefined ? alert_enabled : null,
        id
      ]
    );

    // Fetch updated record
    const [updated] = await pool.query('SELECT * FROM devices WHERE id = ?', [id]);

    res.status(200).json({
      success: true,
      message: 'Device updated successfully.',
      data: updated[0]
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete a device by ID
// @route   DELETE /api/devices/:id
const deleteDevice = async (req, res, next) => {
  const { id } = req.params;

  try {
    const [existing] = await pool.query('SELECT id FROM devices WHERE id = ?', [id]);
    if (existing.length === 0) {
      return res.status(404).json({
        success: false,
        message: `Device with ID ${id} not found.`
      });
    }

    // Delete query
    await pool.query('DELETE FROM devices WHERE id = ?', [id]);

    res.status(200).json({
      success: true,
      message: `Device with ID ${id} has been deleted.`
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getDevices,
  getDeviceById,
  createDevice,
  updateDevice,
  deleteDevice
};
