const bcrypt = require('bcrypt');
const { pool } = require('../db');

// @desc    Register a new user
// @route   POST /api/users/register
const registerUser = async (req, res, next) => {
  const { full_name, email, password } = req.body;

  try {
    // Prevent duplicate email registration
    const [existingUsers] = await pool.query('SELECT id FROM users WHERE email = ?', [email]);
    if (existingUsers.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'A user with this email already exists.'
      });
    }

    // Hash the user password
    const saltRounds = 10;
    const hashedPassword = await bcrypt.hash(password, saltRounds);

    // Save user in DB
    const [result] = await pool.query(
      'INSERT INTO users (full_name, email, password) VALUES (?, ?, ?)',
      [full_name, email, hashedPassword]
    );

    res.status(201).json({
      success: true,
      message: 'User registered successfully.',
      data: {
        id: result.insertId,
        full_name,
        email
      }
    });
  } catch (error) {
    next(error);
  }
};

// @desc    User login verification
// @route   POST /api/users/login
const loginUser = async (req, res, next) => {
  const { email, password } = req.body;

  try {
    // Find the user by email
    const [users] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);
    if (users.length === 0) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password.'
      });
    }

    const user = users[0];

    // Verify hashed password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password.'
      });
    }

    res.status(200).json({
      success: true,
      message: 'Login successful.',
      data: {
        id: user.id,
        full_name: user.full_name,
        email: user.email
      }
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get all users list (excluding password hash)
// @route   GET /api/users
const getUsers = async (req, res, next) => {
  try {
    const [users] = await pool.query('SELECT id, full_name, email FROM users');
    res.status(200).json({
      success: true,
      count: users.length,
      data: users
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  registerUser,
  loginUser,
  getUsers
};
