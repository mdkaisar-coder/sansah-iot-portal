import { Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Cpu, 
  List, 
  Activity, 
  Bell, 
  Settings,
  LogOut,
  PlusCircle
} from 'lucide-react';
import clsx from 'clsx';

const navItems = [
  { name: 'Dashboard', path: '/', icon: LayoutDashboard },
  { name: 'Device List', path: '/devices', icon: List },
  { name: 'Register Device', path: '/devices/new', icon: PlusCircle },
  { name: 'Sensor Monitoring', path: '/sensors', icon: Activity },
  { name: 'Alerts', path: '/alerts', icon: Bell },
  { name: 'Settings', path: '/settings', icon: Settings },
];

export default function Sidebar() {
  const location = useLocation();

  return (
    <div className="w-64 h-screen bg-card border-r border-border flex flex-col fixed left-0 top-0">
      <div className="p-6 border-b border-border flex items-center space-x-3">
        <Cpu className="w-8 h-8 text-primary" />
        <span className="text-xl font-bold text-text">IoT Portal</span>
      </div>
      
      <div className="flex-1 overflow-y-auto py-6">
        <nav className="space-y-1 px-3">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path || (item.path !== '/' && location.pathname.startsWith(item.path));
            const Icon = item.icon;
            
            return (
              <Link
                key={item.name}
                to={item.path}
                className={clsx(
                  "flex items-center px-3 py-2.5 rounded-md text-sm font-medium transition-colors",
                  isActive 
                    ? "bg-primary/10 text-primary" 
                    : "text-muted hover:bg-secondary hover:text-text"
                )}
              >
                <Icon className={clsx("w-5 h-5 mr-3", isActive ? "text-primary" : "text-muted")} />
                {item.name}
              </Link>
            );
          })}
        </nav>
      </div>

      <div className="p-4 border-t border-border">
        <Link
          to="/login"
          className="flex items-center px-3 py-2.5 rounded-md text-sm font-medium text-danger hover:bg-danger/10 transition-colors"
        >
          <LogOut className="w-5 h-5 mr-3" />
          Logout
        </Link>
      </div>
    </div>
  );
}
