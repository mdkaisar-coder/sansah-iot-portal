import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Server, Activity, Tag, MapPin, Calendar, Hash, Cpu, Mail, Phone, User, Bell, BellOff, AlertTriangle } from 'lucide-react';
import StatusBadge from '../components/StatusBadge';

export default function DeviceDetails() {
  const { id } = useParams();
  const [device, setDevice] = useState(null);
  const [alerts, setAlerts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchDeviceDetailsAndAlerts = async () => {
      try {
        setLoading(true);
        setError('');
        
        // 1. Fetch Device Information
        const res = await fetch(`http://localhost:5000/api/devices/${id}`);
        const json = await res.json();
        if (res.ok && json.success) {
          const d = json.data;
          setDevice({
            id: d.id,
            device_code: d.device_code,
            name: d.device_name,
            type: d.device_type,
            protocol: d.protocol,
            project: d.project_name || 'N/A',
            site: d.location || 'N/A',
            status: d.status,
            sensor_type: d.sensor_type || 'N/A',
            client_name: d.client_name || 'N/A',
            client_email: d.client_email || 'N/A',
            client_phone: d.client_phone || 'N/A',
            alert_enabled: d.alert_enabled,
            registeredDate: new Date().toISOString(),
            lastSeen: new Date().toISOString()
          });
        } else {
          setError(json.message || 'Device details not found.');
        }

        // 2. Fetch Recent Alerts
        const alertsRes = await fetch(`http://localhost:5000/api/alerts?device_id=${id}&limit=5`);
        const alertsJson = await alertsRes.json();
        if (alertsRes.ok && alertsJson.success) {
          setAlerts(alertsJson.data);
        }
      } catch (err) {
        console.error('Error fetching device details/alerts:', err);
        setError('Failed to connect to the backend.');
      } finally {
        setLoading(false);
      }
    };

    fetchDeviceDetailsAndAlerts();
  }, [id]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (error || !device) {
    return (
      <div className="space-y-4 max-w-4xl mx-auto">
        <div className="flex items-center space-x-4">
          <Link to="/devices" className="p-2 hover:bg-secondary rounded-full transition-colors text-muted hover:text-text">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <span className="text-muted">Back to inventory</span>
        </div>
        <div className="bg-danger/10 border border-danger text-danger p-6 rounded-xl text-center font-medium">
          {error || 'Device not found.'}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div className="flex items-center space-x-4">
        <Link to="/devices" className="p-2 hover:bg-secondary rounded-full transition-colors text-muted hover:text-text">
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <div>
          <h1 className="text-2xl font-bold text-text flex items-center space-x-3">
            <span>{device.name}</span>
            <StatusBadge status={device.status} />
          </h1>
          <p className="text-muted text-sm mt-1">{device.device_code}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-card border border-border rounded-xl p-6">
          <h2 className="text-lg font-semibold text-text mb-4 border-b border-border pb-2">Device & Location Information</h2>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted flex items-center"><Tag className="w-4 h-4 mr-2" /> Type</span>
              <span className="text-sm font-medium text-text">{device.type}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted flex items-center"><Cpu className="w-4 h-4 mr-2" /> Sensor Category</span>
              <span className="text-sm font-medium text-text">{device.sensor_type}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted flex items-center"><Activity className="w-4 h-4 mr-2" /> Protocol</span>
              <span className="text-sm font-medium text-text">{device.protocol}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted flex items-center"><MapPin className="w-4 h-4 mr-2" /> Location</span>
              <span className="text-sm font-medium text-text">{device.site}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted flex items-center"><Server className="w-4 h-4 mr-2" /> Project Name</span>
              <span className="text-sm font-medium text-text">{device.project}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted flex items-center"><Calendar className="w-4 h-4 mr-2" /> Registered</span>
              <span className="text-sm font-medium text-text">{new Date(device.registeredDate).toLocaleDateString()}</span>
            </div>
          </div>
        </div>

        <div className="bg-card border border-border rounded-xl p-6">
          <h2 className="text-lg font-semibold text-text mb-4 border-b border-border pb-2">Client & Alert Settings</h2>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted flex items-center"><User className="w-4 h-4 mr-2" /> Client Name</span>
              <span className="text-sm font-medium text-text">{device.client_name}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted flex items-center"><Mail className="w-4 h-4 mr-2" /> Client Email</span>
              <span className="text-sm font-medium text-text">{device.client_email}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted flex items-center"><Phone className="w-4 h-4 mr-2" /> Client Phone</span>
              <span className="text-sm font-medium text-text">{device.client_phone}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted flex items-center">
                {device.alert_enabled ? <Bell className="w-4 h-4 mr-2" /> : <BellOff className="w-4 h-4 mr-2" />} 
                Alerts Enabled
              </span>
              <span className={`text-sm font-semibold ${device.alert_enabled ? 'text-success' : 'text-muted'}`}>
                {device.alert_enabled ? 'Yes' : 'No'}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted flex items-center"><Hash className="w-4 h-4 mr-2" /> Last Seen</span>
              <span className="text-sm font-medium text-text">{new Date(device.lastSeen).toLocaleString()}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Alerts Section */}
      <div className="bg-card border border-border rounded-xl p-6">
        <h2 className="text-lg font-semibold text-text mb-4 border-b border-border pb-2 flex items-center space-x-2">
          <AlertTriangle className="w-5 h-5 text-warning" />
          <span>Recent Alerts</span>
        </h2>
        
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="text-xs text-muted uppercase bg-background/50 border-b border-border">
              <tr>
                <th scope="col" className="px-6 py-3">Metric</th>
                <th scope="col" className="px-6 py-3">Current Value</th>
                <th scope="col" className="px-6 py-3">Threshold</th>
                <th scope="col" className="px-6 py-3">Severity</th>
                <th scope="col" className="px-6 py-3">Status</th>
                <th scope="col" className="px-6 py-3">Time</th>
                <th scope="col" className="px-6 py-3">Alert Message</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {alerts.map((alert) => (
                <tr key={alert.id} className="hover:bg-secondary/40 transition-colors">
                  <td className="px-6 py-4 font-semibold text-text font-mono text-xs">{alert.metric_name}</td>
                  <td className="px-6 py-4 font-mono text-danger font-bold">{alert.metric_value}</td>
                  <td className="px-6 py-4 font-mono text-xs text-muted">{alert.threshold_value}</td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-0.5 rounded-full text-xs font-bold uppercase ${
                      alert.severity === 'Critical' ? 'bg-danger/20 text-danger border border-danger/30' :
                      alert.severity === 'High' ? 'bg-orange-500/20 text-orange-500 border border-orange-500/30' :
                      alert.severity === 'Medium' ? 'bg-warning/20 text-warning border border-warning/30' :
                      'bg-primary/20 text-primary border border-primary/30'
                    }`}>
                      {alert.severity}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${
                      alert.status === 'Active' ? 'bg-danger/10 text-danger border border-danger/20' :
                      alert.status === 'Acknowledged' ? 'bg-warning/10 text-warning border border-warning/20' :
                      'bg-success/10 text-success border border-success/20'
                    }`}>
                      {alert.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-xs text-muted">
                    {new Date(alert.created_at).toLocaleString()}
                  </td>
                  <td className="px-6 py-4 text-text">{alert.message}</td>
                </tr>
              ))}
              {alerts.length === 0 && (
                <tr>
                  <td colSpan="7" className="px-6 py-8 text-center text-muted">
                    No alerts logged for this device.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
