import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Cpu } from 'lucide-react';
import FormInput from '../components/FormInput';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const response = await fetch('http://localhost:5000/api/users/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email, password })
      });

      const data = await response.json();
      if (response.ok && data.success) {
        navigate('/');
      } else {
        setError(data.message || 'Invalid email or password.');
      }
    } catch (err) {
      console.error(err);
      setError('Connection to backend failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full max-w-md bg-card p-8 rounded-xl border border-border shadow-2xl">
      <div className="flex flex-col items-center mb-8">
        <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mb-4">
          <Cpu className="w-8 h-8 text-primary" />
        </div>
        <h1 className="text-2xl font-bold text-text">IoT Portal Admin</h1>
        <p className="text-sm text-muted mt-2">Sign in to your account</p>
      </div>

      {error && (
        <div className="bg-danger/10 border border-danger text-danger p-3 rounded-md text-sm text-center mb-4 font-medium">
          {error}
        </div>
      )}

      <form onSubmit={handleLogin} className="space-y-5">
        <FormInput 
          label="Email Address" 
          type="email" 
          id="email" 
          placeholder="admin@iotportal.local"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <FormInput 
          label="Password" 
          type="password" 
          id="password" 
          placeholder="••••••••"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        
        <button 
          type="submit" 
          disabled={loading}
          className="w-full bg-primary hover:bg-primary/90 text-white font-medium py-2.5 rounded-md transition-colors mt-4 flex items-center justify-center"
        >
          {loading ? (
            <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
          ) : 'Sign In'}
        </button>
      </form>
    </div>
  );
}
