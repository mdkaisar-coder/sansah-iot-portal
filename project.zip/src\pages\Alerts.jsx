import { useEffect, useState } from 'react';
import { AlertTriangle, Clock, Server, CheckCircle2, Eye, ShieldAlert, Check, HelpCircle } from 'lucide-react';
import TableComponent from '../components/TableComponent';
import StatusBadge from '../components/StatusBadge';

export default function Alerts() {
  const [alertsList, setAlertsList] = useState([]);
  const [stats, setStats] = useState({
    total: 0,
    active: 0,
    acknowledged: 0,
    resolved: 0,
    critical: 0,
    high: 0,
    medium: 0,
    low: 0
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [severityFilter, setSeverityFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');
  const [page, setPage] = useState(1);
  const [totalCount, setTotalCount] = useState(0);
  const [selectedAlert, setSelectedAlert] = useState(null); // For details modal
  const limit = 10;

  const fetchAlertsAndStats = async () => {
    try {
      setLoading(true);
      setError('');

      // Build query string
      let url = `http://localhost:5000/api/alerts?page=${page}&limit=${limit}`;
      if (severityFilter !== 'All') url += `&severity=${severityFilter}`;
      if (statusFilter !== 'All') url += `&status=${statusFilter}`;

      // Fetch stats
      const statsRes = await fetch('http://localhost:5000/api/alerts/stats');
      const statsJson = await statsRes.json();
      if (statsRes.ok && statsJson.success) {
        setStats(statsJson.data);
      }

      // Fetch list
      const res = await fetch(url);
      const json = await res.json();
      if (res.ok && json.success) {
        setAlertsList(json.data);
        setTotalCount(json.total);
      } else {
        setError(json.message || 'Failed to retrieve alerts.');
      }
    } catch (err) {
      console.error(err);
      setError('Failed to connect to the backend.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAlertsAndStats();
  }, [page, severityFilter, statusFilter]);

  const handleAcknowledge = async (id) => {
    try {
      const response = await fetch(`http://localhost:5000/api/alerts/${id}/acknowledge`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' }
      });
      const data = await response.json();
      if (response.ok && data.success) {
        fetchAlertsAndStats();
        if (selectedAlert && selectedAlert.id === id) {
          setSelectedAlert(data.data);
        }
      } else {
        alert(data.message || 'Failed to acknowledge alert.');
      }
    } catch (err) {
      console.error(err);
      alert('Failed to acknowledge alert.');
    }
  };

  const handleResolve = async (id) => {
    try {
      const response = await fetch(`http://localhost:5000/api/alerts/${id}/resolve`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' }
      });
      const data = await response.json();
      if (response.ok && data.success) {
        fetchAlertsAndStats();
        if (selectedAlert && selectedAlert.id === id) {
          setSelectedAlert(data.data);
        }
      } else {
        alert(data.message || 'Failed to resolve alert.');
      }
    } catch (err) {
      console.error(err);
      alert('Failed to resolve alert.');
    }
  };

  const totalPages = Math.ceil(totalCount / limit) || 1;

  const getSeverityBadgeClass = (severity) => {
    switch (severity) {
      case 'Critical': return 'bg-danger/20 text-danger border border-danger/30';
      case 'High': return 'bg-orange-500/20 text-orange-500 border border-orange-500/30';
      case 'Medium': return 'bg-warning/20 text-warning border border-warning/30';
      case 'Low': return 'bg-primary/20 text-primary border border-primary/30';
      default: return 'bg-muted/20 text-muted';
    }
  };

  const getStatusBadgeClass = (status) => {
    switch (status) {
      case 'Active': return 'bg-danger/10 text-danger border border-danger/20';
      case 'Acknowledged': return 'bg-warning/10 text-warning border border-warning/20';
      case 'Resolved': return 'bg-success/10 text-success border border-success/20';
      default: return 'bg-muted/10 text-muted';
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-text">Alert Management Center</h1>
        <p className="text-muted text-sm mt-1">Real-time telemetry anomaly detection and alert lifecycle management.</p>
      </div>

      {/* Stats Cards Dashboard */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-card border border-border rounded-xl p-5 flex items-center space-x-4">
          <div className="p-3 bg-muted/15 text-muted rounded-lg">
            <HelpCircle className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs text-muted font-medium uppercase tracking-wider block">Total Alerts</span>
            <span className="text-2xl font-bold text-text mt-0.5">{stats.total}</span>
          </div>
        </div>

        <div className="bg-card border border-border rounded-xl p-5 flex items-center space-x-4">
          <div className="p-3 bg-danger/15 text-danger rounded-lg">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs text-muted font-medium uppercase tracking-wider block">Active Alerts</span>
            <span className="text-2xl font-bold text-text mt-0.5">{stats.active}</span>
          </div>
        </div>

        <div className="bg-card border border-border rounded-xl p-5 flex items-center space-x-4">
          <div className="p-3 bg-orange-500/15 text-orange-500 rounded-lg">
            <ShieldAlert className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs text-muted font-medium uppercase tracking-wider block">Critical Alerts</span>
            <span className="text-2xl font-bold text-text mt-0.5">{stats.critical}</span>
          </div>
        </div>

        <div className="bg-card border border-border rounded-xl p-5 flex items-center space-x-4">
          <div className="p-3 bg-success/15 text-success rounded-lg">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs text-muted font-medium uppercase tracking-wider block">Resolved Alerts</span>
            <span className="text-2xl font-bold text-text mt-0.5">{stats.resolved}</span>
          </div>
        </div>
      </div>

      {/* Filters & Actions Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-card border border-border rounded-xl p-4">
        <div className="flex flex-wrap items-center gap-4">
          <div className="flex flex-col space-y-1">
            <label className="text-xs text-muted font-semibold uppercase">Status Filter</label>
            <select
              value={statusFilter}
              onChange={(e) => { setStatusFilter(e.target.value); setPage(1); }}
              className="bg-background border border-border rounded-md px-3 py-1.5 text-sm text-text focus:outline-none focus:border-primary"
            >
              <option value="All">All Statuses</option>
              <option value="Active">Active</option>
              <option value="Acknowledged">Acknowledged</option>
              <option value="Resolved">Resolved</option>
            </select>
          </div>

          <div className="flex flex-col space-y-1">
            <label className="text-xs text-muted font-semibold uppercase">Severity Filter</label>
            <select
              value={severityFilter}
              onChange={(e) => { setSeverityFilter(e.target.value); setPage(1); }}
              className="bg-background border border-border rounded-md px-3 py-1.5 text-sm text-text focus:outline-none focus:border-primary"
            >
              <option value="All">All Severities</option>
              <option value="Critical">Critical</option>
              <option value="High">High</option>
              <option value="Medium">Medium</option>
              <option value="Low">Low</option>
            </select>
          </div>
        </div>

        <button
          onClick={fetchAlertsAndStats}
          className="px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary/95 rounded-md transition-colors w-full sm:w-auto mt-4 sm:mt-0"
        >
          Refresh Feeds
        </button>
      </div>

      {/* Main Table Grid */}
      {error ? (
        <div className="bg-danger/10 border border-danger text-danger p-4 rounded-xl text-center font-medium">
          {error}
        </div>
      ) : (
        <div className="space-y-4">
          <TableComponent headers={['Device', 'Client', 'Project', 'Sensor Type', 'Metric', 'Current Value', 'Threshold', 'Severity', 'Status', 'Created Time', 'Actions']}>
            {alertsList.map((alert) => (
              <tr key={alert.id} className="hover:bg-secondary/40 transition-colors">
                <td className="px-6 py-4">
                  <div className="font-semibold text-text">{alert.device_name}</div>
                  <div className="text-xs text-muted font-mono">{alert.device_code || 'N/A'}</div>
                </td>
                <td className="px-6 py-4 text-text">{alert.client_name || 'N/A'}</td>
                <td className="px-6 py-4 text-text">{alert.project_name || 'N/A'}</td>
                <td className="px-6 py-4 text-text text-xs font-semibold">{alert.sensor_type}</td>
                <td className="px-6 py-4 text-text font-mono text-xs">{alert.metric_name}</td>
                <td className="px-6 py-4 font-bold font-mono text-danger">{alert.metric_value}</td>
                <td className="px-6 py-4 font-mono text-xs text-muted">{alert.threshold_value}</td>
                <td className="px-6 py-4">
                  <span className={`px-2 py-0.5 rounded-full text-xs font-bold uppercase ${getSeverityBadgeClass(alert.severity)}`}>
                    {alert.severity}
                  </span>
                </td>
                <td className="px-6 py-4">
                  <span className={`px-2 py-1 rounded-full text-xs font-semibold ${getStatusBadgeClass(alert.status)}`}>
                    {alert.status}
                  </span>
                </td>
                <td className="px-6 py-4 text-muted text-xs">
                  {new Date(alert.created_at).toLocaleString()}
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => setSelectedAlert(alert)}
                      title="View Details"
                      className="p-1.5 hover:bg-secondary text-primary rounded-md transition-colors"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                    {alert.status === 'Active' && (
                      <button
                        onClick={() => handleAcknowledge(alert.id)}
                        title="Acknowledge Alert"
                        className="p-1.5 hover:bg-secondary text-warning rounded-md transition-colors"
                      >
                        <Clock className="w-4 h-4" />
                      </button>
                    )}
                    {alert.status !== 'Resolved' && (
                      <button
                        onClick={() => handleResolve(alert.id)}
                        title="Resolve Alert"
                        className="p-1.5 hover:bg-secondary text-success rounded-md transition-colors"
                      >
                        <Check className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
            {alertsList.length === 0 && (
              <tr>
                <td colSpan="11" className="px-6 py-12 text-center text-muted">
                  No active or historical alerts match the current filter selection.
                </td>
              </tr>
            )}
          </TableComponent>

          {/* Pagination Controls */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between pt-2">
              <span className="text-sm text-muted">
                Showing page <strong className="text-text">{page}</strong> of <strong className="text-text">{totalPages}</strong> ({totalCount} total alerts)
              </span>
              <div className="flex items-center space-x-2">
                <button
                  disabled={page === 1}
                  onClick={() => setPage(p => Math.max(p - 1, 1))}
                  className="px-3 py-1.5 text-xs font-semibold text-text bg-card border border-border hover:bg-secondary disabled:opacity-50 disabled:cursor-not-allowed rounded-md transition-colors"
                >
                  Previous
                </button>
                <button
                  disabled={page === totalPages}
                  onClick={() => setPage(p => Math.min(p + 1, totalPages))}
                  className="px-3 py-1.5 text-xs font-semibold text-text bg-card border border-border hover:bg-secondary disabled:opacity-50 disabled:cursor-not-allowed rounded-md transition-colors"
                >
                  Next
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Details View Modal */}
      {selectedAlert && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-card border border-border rounded-xl w-full max-w-lg overflow-hidden shadow-2xl flex flex-col animate-in fade-in-50 zoom-in-95 duration-200">
            <div className="p-5 border-b border-border flex justify-between items-center bg-background/50">
              <h2 className="text-lg font-bold text-text flex items-center space-x-2">
                <AlertTriangle className={`w-5 h-5 ${selectedAlert.severity === 'Critical' ? 'text-danger' : 'text-warning'}`} />
                <span>Alert Profile details</span>
              </h2>
              <button
                onClick={() => setSelectedAlert(null)}
                className="text-muted hover:text-text text-xl font-semibold p-1 hover:bg-secondary rounded-md"
              >
                &times;
              </button>
            </div>
            
            <div className="p-6 overflow-y-auto space-y-4 max-h-[70vh]">
              <div className="bg-secondary/20 p-4 rounded-lg border border-border/50">
                <span className="text-xs text-muted block uppercase tracking-wider font-semibold">Incident Message</span>
                <p className="text-sm font-semibold text-text mt-1">{selectedAlert.message}</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <span className="text-xs text-muted block">Device Profile</span>
                  <span className="text-sm text-text font-semibold">{selectedAlert.device_name}</span>
                  <span className="text-xs text-muted block font-mono">{selectedAlert.device_code || 'N/A'}</span>
                </div>
                <div>
                  <span className="text-xs text-muted block">Sensor Category</span>
                  <span className="text-sm text-text font-semibold">{selectedAlert.sensor_type}</span>
                </div>
                <div>
                  <span className="text-xs text-muted block">Metric / Reading</span>
                  <span className="text-sm text-text font-semibold">{selectedAlert.metric_name}</span>
                  <span className="text-xs text-danger font-semibold font-mono block">Current: {selectedAlert.metric_value}</span>
                </div>
                <div>
                  <span className="text-xs text-muted block">Threshold Reference</span>
                  <span className="text-sm text-text font-semibold font-mono">{selectedAlert.threshold_value}</span>
                </div>
                <div>
                  <span className="text-xs text-muted block">Severity</span>
                  <span className={`px-2 py-0.5 rounded-full text-xs font-bold uppercase inline-block mt-0.5 ${getSeverityBadgeClass(selectedAlert.severity)}`}>
                    {selectedAlert.severity}
                  </span>
                </div>
                <div>
                  <span className="text-xs text-muted block">Status State</span>
                  <span className={`px-2 py-0.5 rounded-full text-xs font-semibold inline-block mt-0.5 ${getStatusBadgeClass(selectedAlert.status)}`}>
                    {selectedAlert.status}
                  </span>
                </div>
              </div>

              <hr className="border-border" />

              <div>
                <span className="text-xs font-bold uppercase text-muted tracking-wider block mb-2">Client Details & Deployment</span>
                <div className="grid grid-cols-2 gap-3 bg-secondary/10 p-3 rounded-lg border border-border/30 text-xs">
                  <div>
                    <span className="text-muted block">Client Name</span>
                    <span className="text-text font-semibold">{selectedAlert.client_name || 'N/A'}</span>
                  </div>
                  <div>
                    <span className="text-muted block">Project Name</span>
                    <span className="text-text font-semibold">{selectedAlert.project_name || 'N/A'}</span>
                  </div>
                  <div>
                    <span className="text-muted block">Client Email</span>
                    <span className="text-text font-mono truncate block" title={selectedAlert.client_email}>{selectedAlert.client_email || 'N/A'}</span>
                  </div>
                  <div>
                    <span className="text-muted block">Location / Site</span>
                    <span className="text-text font-semibold">{selectedAlert.location || 'N/A'}</span>
                  </div>
                </div>
              </div>

              <hr className="border-border" />

              <div className="space-y-2 text-xs text-muted">
                <div className="flex justify-between">
                  <span>Created At:</span>
                  <span className="text-text font-medium">{new Date(selectedAlert.created_at).toLocaleString()}</span>
                </div>
                {selectedAlert.acknowledged_at && (
                  <div className="flex justify-between">
                    <span>Acknowledged At:</span>
                    <span className="text-text font-medium">{new Date(selectedAlert.acknowledged_at).toLocaleString()}</span>
                  </div>
                )}
                {selectedAlert.resolved_at && (
                  <div className="flex justify-between">
                    <span>Resolved At:</span>
                    <span className="text-text font-medium">{new Date(selectedAlert.resolved_at).toLocaleString()}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>Email Notification Sent:</span>
                  <span className={`font-semibold ${selectedAlert.email_sent ? 'text-success' : 'text-muted'}`}>
                    {selectedAlert.email_sent ? 'Yes' : 'No'}
                  </span>
                </div>
              </div>
            </div>

            <div className="p-4 border-t border-border flex justify-end space-x-3 bg-background/50">
              {selectedAlert.status === 'Active' && (
                <button
                  onClick={() => handleAcknowledge(selectedAlert.id)}
                  className="px-3 py-1.5 text-xs font-semibold text-text bg-secondary hover:bg-secondary/80 rounded-md transition-colors"
                >
                  Acknowledge
                </button>
              )}
              {selectedAlert.status !== 'Resolved' && (
                <button
                  onClick={() => handleResolve(selectedAlert.id)}
                  className="px-3 py-1.5 text-xs font-semibold text-white bg-success hover:bg-success/90 rounded-md transition-colors"
                >
                  Resolve Alert
                </button>
              )}
              <button
                onClick={() => setSelectedAlert(null)}
                className="px-3 py-1.5 text-xs font-semibold text-text bg-card border border-border hover:bg-secondary rounded-md transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
