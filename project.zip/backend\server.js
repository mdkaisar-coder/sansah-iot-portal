const express = require('express');
const cors = require('cors');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '.env') });

const { testConnection } = require('./db');
const devicesRouter = require('./routes/devices');
const usersRouter = require('./routes/users');
const alertsRouter = require('./routes/alerts');
const sensorsRouter = require('./routes/sensors');
const dashboardRouter = require('./routes/dashboard');
const errorHandler = require('./middleware/errorHandler');

const app = express();
const PORT = process.env.PORT || 5000;

// CORS configuration - Allow designated React clients
const corsOptions = {
  origin: ['http://localhost:5173', 'http://localhost:5174'],
  optionsSuccessStatus: 200
};
app.use(cors(corsOptions));

// Request payload parsing middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Request logging middleware with payload output
app.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
  if (req.method !== 'GET' && req.body && Object.keys(req.body).length > 0) {
    console.log('Request Payload:', JSON.stringify(req.body, null, 2));
  }
  next();
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.status(200).json({
    status: 'healthy',
    timestamp: new Date()
  });
});

// Mount Routes
app.use('/api/devices', devicesRouter);
app.use('/api/users', usersRouter);
app.use('/api/alerts', alertsRouter);
app.use('/api/sensors', sensorsRouter);
app.use('/api/dashboard', dashboardRouter);

// Test Email Endpoint
const { sendTestEmail } = require('./services/emailService');
app.post('/api/test-email', async (req, res) => {
  try {
    const info = await sendTestEmail();
    res.status(200).json({
      success: true,
      message: 'Test email sent successfully.',
      accepted: info.accepted,
      rejected: info.rejected,
      response: info.response,
      messageId: info.messageId
    });
  } catch (error) {
    console.error('TestEmail Route Error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to send test email.',
      error: error.message
    });
  }
});

// 404 Route handling
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: `Endpoint ${req.method} ${req.originalUrl} not found.`
  });
});

// Global error handling middleware
app.use(errorHandler);

// Database verification and Server startup
async function startServer() {
  try {
    // 1. Verify database connection
    await testConnection();

    // 2. Start server
    app.listen(PORT, () => {
      console.log(`Server Running on Port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to initialize server due to database connectivity issue.');
    process.exit(1);
  }
}

startServer();
