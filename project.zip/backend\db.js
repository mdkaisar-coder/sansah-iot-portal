const mysql = require('mysql2/promise');
const path = require('path');

// Load .env reliably using absolute path relative to this script
require('dotenv').config({ path: path.join(__dirname, '.env') });

// Detailed startup connection log (excluding actual password for security)
console.log('Database Connection Attempt Details:');
console.log(`- Host: ${process.env.DB_HOST || 'localhost'}`);
console.log(`- Database: ${process.env.DB_NAME || 'iot_portal'}`);
console.log(`- Port: ${process.env.DB_PORT || '3306'}`);
console.log(`- User: ${process.env.DB_USER || 'root'}`);
console.log(`- Password Exists: ${process.env.DB_PASSWORD ? 'true' : 'false'}`);

// Create connection pool
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT || '3306', 10),
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'iot_portal',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// Test database connection
async function testConnection() {
  try {
    const connection = await pool.getConnection();
    console.log('Database Connected Successfully');
    connection.release();
  } catch (error) {
    console.error('Database connection verification failed:', error.message);
    throw error;
  }
}

module.exports = {
  pool,
  testConnection
};
