import { MapPin, Server, Tag, Cpu, User } from 'lucide-react';
import StatusBadge from './StatusBadge';
import { Link } from 'react-router-dom';

export default function DeviceCard({ device }) {
  return (
    <div className="bg-card rounded-lg border border-border p-5 hover:border-primary/50 transition-colors flex flex-col h-full">
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="text-lg font-bold text-text">{device.name}</h3>
          <p className="text-xs text-muted font-mono mt-1">{device.device_code}</p>
        </div>
        <StatusBadge status={device.status} />
      </div>

      <div className="flex-1 space-y-3 mb-6">
        <div className="flex items-center text-sm text-muted">
          <Tag className="w-4 h-4 mr-2" />
          <span className="w-24">Type:</span>
          <span className="text-text font-medium">{device.type}</span>
        </div>
        <div className="flex items-center text-sm text-muted">
          <Cpu className="w-4 h-4 mr-2" />
          <span className="w-24">Category:</span>
          <span className="text-text font-medium truncate" title={device.sensor_type}>{device.sensor_type || 'N/A'}</span>
        </div>
        <div className="flex items-center text-sm text-muted">
          <User className="w-4 h-4 mr-2" />
          <span className="w-24">Client Name:</span>
          <span className="text-text font-medium truncate" title={device.client_name}>{device.client_name || 'N/A'}</span>
        </div>
        <div className="flex items-center text-sm text-muted">
          <Server className="w-4 h-4 mr-2" />
          <span className="w-24">Project Name:</span>
          <span className="text-text font-medium truncate" title={device.project}>{device.project || 'N/A'}</span>
        </div>
        <div className="flex items-center text-sm text-muted">
          <MapPin className="w-4 h-4 mr-2" />
          <span className="w-24">Location:</span>
          <span className="text-text font-medium truncate" title={device.site}>{device.site}</span>
        </div>
      </div>

      <div className="pt-4 border-t border-border flex justify-between items-center">
        <span className="text-xs text-muted">Added {new Date(device.registeredDate).toLocaleDateString()}</span>
        <Link
          to={`/devices/${device.id}`}
          className="text-sm font-medium text-primary hover:text-primary/80 transition-colors"
        >
          View Details
        </Link>
      </div>
    </div>
  );
}
