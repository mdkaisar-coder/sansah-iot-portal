import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import FormInput from '../components/FormInput';

const sensorCategories = [
  'Temperature Sensor',
  'Humidity Sensor',
  'Pressure Sensor',
  'Air Quality Sensor',
  'Water Level Sensor',
  'Flow Sensor',
  'Motion Sensor',
  'Light Sensor',
  'Smoke Sensor',
  'Gas Sensor',
  'Vibration Sensor',
  'Soil Moisture Sensor',
  'Power Meter',
  'Battery Monitor',
  'GPS Tracker'
];

export default function RegisterDevice() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: '',
    id: '',
    type: 'Sensor',
    protocol: 'MQTT',
    project: '',
    site: '',
    status: 'Online',
    sensor_type: 'Temperature Sensor',
    client_name: '',
    client_email: '',
    client_phone: '',
    alert_enabled: 'true'
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    const payload = {
      device_name: formData.name,
      device_code: formData.id,
      device_type: formData.type,
      protocol: formData.protocol,
      project_name: formData.project,
      location: formData.site,
      status: formData.status,
      sensor_type: formData.sensor_type,
      client_name: formData.client_name,
      client_email: formData.client_email,
      client_phone: formData.client_phone,
      alert_enabled: formData.alert_enabled === 'true'
    };

    console.log('Sending Device Registration Payload:', payload);

    try {
      const response = await fetch('http://localhost:5000/api/devices', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      });

      console.log('Response Status:', response.status);
      const data = await response.json();
      console.log('Response Body:', data);

      if ((response.status === 200 || response.status === 201) && data.success) {
        alert(`Device ${formData.name} registered successfully!`);
        handleReset();
        navigate('/devices');
      } else {
        setError(data.message || 'Failed to register device.');
      }
    } catch (err) {
      console.error('Connection Error:', err);
      setError('Connection to backend failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setFormData({
      name: '',
      id: '',
      type: 'Sensor',
      protocol: 'MQTT',
      project: '',
      site: '',
      status: 'Online',
      sensor_type: 'Temperature Sensor',
      client_name: '',
      client_email: '',
      client_phone: '',
      alert_enabled: 'true'
    });
    setError('');
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-text">Register New Device</h1>
        <p className="text-muted text-sm mt-1">Onboard a new IoT device to the platform.</p>
      </div>

      {error && (
        <div className="bg-danger/10 border border-danger text-danger p-4 rounded-lg text-sm font-medium">
          {error}
        </div>
      )}

      <div className="bg-card border border-border rounded-xl p-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <FormInput 
              label="Device Name *" 
              name="name"
              placeholder="e.g. Warehouse Temp Sensor" 
              value={formData.name}
              onChange={handleChange}
              required 
            />
            <FormInput 
              label="Device ID *" 
              name="id"
              placeholder="e.g. DEV-2001" 
              value={formData.id}
              onChange={handleChange}
              required 
            />
            
            <div className="flex flex-col space-y-1.5">
              <label className="text-sm font-medium text-text">Device Type *</label>
              <select 
                name="type"
                value={formData.type}
                onChange={handleChange}
                className="w-full bg-background border border-border rounded-md px-3 py-2 text-sm text-text focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary"
              >
                <option value="Sensor">Sensor</option>
                <option value="Actuator">Actuator</option>
                <option value="Gateway">Gateway</option>
                <option value="Camera">Camera</option>
              </select>
            </div>

            <div className="flex flex-col space-y-1.5">
              <label className="text-sm font-medium text-text">Sensor Category *</label>
              <select 
                name="sensor_type"
                value={formData.sensor_type}
                onChange={handleChange}
                className="w-full bg-background border border-border rounded-md px-3 py-2 text-sm text-text focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary"
              >
                {sensorCategories.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
              <span className="text-xs text-muted mt-1">
                This selection determines which telemetry metrics will be monitored.
              </span>
            </div>

            <div className="flex flex-col space-y-1.5">
              <label className="text-sm font-medium text-text">Protocol *</label>
              <select 
                name="protocol"
                value={formData.protocol}
                onChange={handleChange}
                className="w-full bg-background border border-border rounded-md px-3 py-2 text-sm text-text focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary"
              >
                <option value="MQTT">MQTT</option>
                <option value="HTTP">HTTP</option>
                <option value="CoAP">CoAP</option>
              </select>
            </div>

            <FormInput 
              label="Project Name *" 
              name="project"
              placeholder="e.g. Alpha Operations" 
              value={formData.project}
              onChange={handleChange}
              required 
            />

            <FormInput 
              label="Location *" 
              name="site"
              placeholder="e.g. Warehouse 1, Factory A, Plant 3, Site B, Building 2" 
              value={formData.site}
              onChange={handleChange}
              required 
            />

            <div className="flex flex-col space-y-1.5">
              <label className="text-sm font-medium text-text">Initial Status *</label>
              <select 
                name="status"
                value={formData.status}
                onChange={handleChange}
                className="w-full bg-background border border-border rounded-md px-3 py-2 text-sm text-text focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary"
              >
                <option value="Online">Online</option>
                <option value="Offline">Offline</option>
              </select>
            </div>

            <FormInput 
              label="Client Name *" 
              name="client_name"
              placeholder="e.g. Acme Corp" 
              value={formData.client_name}
              onChange={handleChange}
              required 
            />

            <FormInput 
              label="Client Email *" 
              name="client_email"
              type="email"
              placeholder="e.g. contact@acme.com" 
              value={formData.client_email}
              onChange={handleChange}
              required 
            />

            <FormInput 
              label="Client Phone *" 
              name="client_phone"
              placeholder="e.g. +1 555-0199" 
              value={formData.client_phone}
              onChange={handleChange}
              required 
            />

            <div className="flex flex-col space-y-1.5">
              <label className="text-sm font-medium text-text">Alerts Enabled *</label>
              <select 
                name="alert_enabled"
                value={formData.alert_enabled}
                onChange={handleChange}
                className="w-full bg-background border border-border rounded-md px-3 py-2 text-sm text-text focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary"
              >
                <option value="true">Yes</option>
                <option value="false">No</option>
              </select>
            </div>
          </div>

          <div className="flex items-center justify-end space-x-4 pt-4 border-t border-border">
            <button 
              type="button" 
              onClick={handleReset}
              disabled={loading}
              className="px-4 py-2 text-sm font-medium text-text bg-secondary hover:bg-secondary/80 rounded-md transition-colors"
            >
              Reset
            </button>
            <button 
              type="submit" 
              disabled={loading}
              className="px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary/90 rounded-md transition-colors flex items-center justify-center min-w-[100px]"
            >
              {loading ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              ) : 'Save Device'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
