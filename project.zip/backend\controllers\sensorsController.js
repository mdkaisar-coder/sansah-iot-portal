const { pool } = require('../db');
const { generateTelemetryOnDemand } = require('../services/telemetryService');

// @desc    Get all sensor data
// @route   GET /api/sensors
const getSensors = async (req, res, next) => {
  const { deviceId } = req.query;
  try {
    // Trigger on-demand telemetry generation check
    await generateTelemetryOnDemand(deviceId);

    let query = `
      SELECT 
        s.id, 
        s.device_id, 
        d.device_name,
        d.device_code,
        s.sensor_name, 
        s.sensor_value, 
        s.recorded_at
      FROM sensor_data s
      LEFT JOIN devices d ON s.device_id = d.id
    `;
    let params = [];
    if (deviceId) {
      query += ` WHERE s.device_id = ?`;
      params.push(deviceId);
    }
    query += ` ORDER BY s.recorded_at DESC`;

    const [sensors] = await pool.query(query, params);
    res.status(200).json({
      success: true,
      count: sensors.length,
      data: sensors
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Create a new sensor reading
// @route   POST /api/sensors
const createSensor = async (req, res, next) => {
  const { device_id, sensor_name, sensor_value, recorded_at } = req.body;

  try {
    // Check if referenced device exists
    const [device] = await pool.query('SELECT id FROM devices WHERE id = ?', [device_id]);
    if (device.length === 0) {
      return res.status(404).json({
        success: false,
        message: `Device with ID ${device_id} does not exist.`
      });
    }

    const timestamp = recorded_at ? new Date(recorded_at) : new Date();

    const [result] = await pool.query(
      'INSERT INTO sensor_data (device_id, sensor_name, sensor_value, recorded_at) VALUES (?, ?, ?, ?)',
      [device_id, sensor_name, sensor_value, timestamp]
    );

    res.status(201).json({
      success: true,
      message: 'Sensor data logged successfully.',
      data: {
        id: result.insertId,
        device_id,
        sensor_name,
        sensor_value,
        recorded_at: timestamp
      }
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update a sensor reading by ID
// @route   PUT /api/sensors/:id
const updateSensor = async (req, res, next) => {
  const { id } = req.params;
  const { device_id, sensor_name, sensor_value, recorded_at } = req.body;

  try {
    const [existing] = await pool.query('SELECT id FROM sensor_data WHERE id = ?', [id]);
    if (existing.length === 0) {
      return res.status(404).json({
        success: false,
        message: `Sensor record with ID ${id} not found.`
      });
    }

    // Verify the device exists if the update tries to change the device_id
    if (device_id) {
      const [device] = await pool.query('SELECT id FROM devices WHERE id = ?', [device_id]);
      if (device.length === 0) {
        return res.status(404).json({
          success: false,
          message: `Device with ID ${device_id} does not exist.`
        });
      }
    }

    await pool.query(
      `UPDATE sensor_data SET 
        device_id = COALESCE(?, device_id),
        sensor_name = COALESCE(?, sensor_name),
        sensor_value = COALESCE(?, sensor_value),
        recorded_at = COALESCE(?, recorded_at)
       WHERE id = ?`,
      [
        device_id || null,
        sensor_name || null,
        sensor_value || null,
        recorded_at ? new Date(recorded_at) : null,
        id
      ]
    );

    const [updated] = await pool.query('SELECT * FROM sensor_data WHERE id = ?', [id]);

    res.status(200).json({
      success: true,
      message: 'Sensor data updated successfully.',
      data: updated[0]
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete a sensor reading by ID
// @route   DELETE /api/sensors/:id
const deleteSensor = async (req, res, next) => {
  const { id } = req.params;

  try {
    const [existing] = await pool.query('SELECT id FROM sensor_data WHERE id = ?', [id]);
    if (existing.length === 0) {
      return res.status(404).json({
        success: false,
        message: `Sensor record with ID ${id} not found.`
      });
    }

    await pool.query('DELETE FROM sensor_data WHERE id = ?', [id]);

    res.status(200).json({
      success: true,
      message: `Sensor record with ID ${id} has been deleted.`
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getSensors,
  createSensor,
  updateSensor,
  deleteSensor
};
