import { useEffect, useState } from 'react';
import { Search, Filter } from 'lucide-react';
import DeviceCard from '../components/DeviceCard';

export default function DeviceList() {
  const [devices, setDevices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');

  useEffect(() => {
    const fetchDevices = async () => {
      try {
        setLoading(true);
        setError('');
        const res = await fetch('http://localhost:5000/api/devices');
        const json = await res.json();
        if (res.ok && json.success) {
          const mappedDevices = json.data.map(d => ({
            id: d.id,
            device_code: d.device_code,
            name: d.device_name,
            type: d.device_type,
            protocol: d.protocol,
            project: d.project_name || 'N/A',
            site: d.location || 'N/A',
            status: d.status,
            sensor_type: d.sensor_type || 'N/A',
            client_name: d.client_name || 'N/A',
            registeredDate: new Date().toISOString()
          }));
          setDevices(mappedDevices);
        } else {
          setError(json.message || 'Failed to retrieve devices.');
        }
      } catch (err) {
        console.error('Error fetching devices:', err);
        setError('Failed to connect to the backend.');
      } finally {
        setLoading(false);
      }
    };

    fetchDevices();
  }, []);

  const filteredDevices = devices.filter(device => {
    const matchesSearch = device.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          device.device_code.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'All' || device.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-danger/10 border border-danger text-danger p-4 rounded-lg text-center font-medium">
        {error}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-4">
        <div>
          <h1 className="text-2xl font-bold text-text">Device Inventory</h1>
          <p className="text-muted text-sm mt-1">Manage and monitor all registered devices.</p>
        </div>
        
        <div className="flex items-center space-x-4 w-full sm:w-auto">
          <div className="relative flex-1 sm:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted" />
            <input 
              type="text" 
              placeholder="Search devices..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-card border border-border rounded-md pl-10 pr-4 py-2 text-sm text-text focus:outline-none focus:border-primary"
            />
          </div>
          <div className="relative">
            <Filter className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted" />
            <select 
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="bg-card border border-border rounded-md pl-10 pr-8 py-2 text-sm text-text focus:outline-none focus:border-primary appearance-none cursor-pointer"
            >
              <option value="All">All Status</option>
              <option value="Online">Online</option>
              <option value="Offline">Offline</option>
            </select>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredDevices.map(device => (
          <DeviceCard key={device.id} device={device} />
        ))}
        {filteredDevices.length === 0 && (
          <div className="col-span-full py-12 text-center text-muted">
            No devices found matching your criteria.
          </div>
        )}
      </div>
    </div>
  );
}
