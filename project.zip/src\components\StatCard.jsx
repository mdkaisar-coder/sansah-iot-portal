export default function StatCard({ title, value, icon: Icon, colorClass }) {
  return (
    <div className="bg-card p-6 rounded-lg border border-border flex items-center justify-between hover:border-primary/50 transition-colors">
      <div>
        <p className="text-sm font-medium text-muted mb-1">{title}</p>
        <p className="text-3xl font-bold text-text">{value}</p>
      </div>
      <div className={`p-4 rounded-full ${colorClass}`}>
        <Icon className="w-6 h-6" />
      </div>
    </div>
  );
}
