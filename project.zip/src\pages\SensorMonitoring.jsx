import { useEffect, useState, useMemo } from 'react';
import { 
  Thermometer, 
  Droplets, 
  Gauge, 
  Battery, 
  Signal, 
  Activity, 
  Zap, 
  Sun, 
  AlertTriangle, 
  Eye, 
  Compass, 
  Cpu, 
  Heart,
  Server,
  Radio
} from 'lucide-react';
import StatusBadge from '../components/StatusBadge';

export default function SensorMonitoring() {
  const [devices, setDevices] = useState([]);
  const [selectedDeviceId, setSelectedDeviceId] = useState('');
  const [telemetry, setTelemetry] = useState({});
  const [activeAlerts, setActiveAlerts] = useState([]);
  const [lastUpdated, setLastUpdated] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [timeAgo, setTimeAgo] = useState('');

  // 1. Fetch devices for dropdown
  useEffect(() => {
    const fetchDevices = async () => {
      try {
        setError('');
        const res = await fetch('http://localhost:5000/api/devices');
        const json = await res.json();
        if (res.ok && json.success) {
          // Filter to show devices with sensor categories
          const sensorDevices = json.data.filter(d => d.sensor_type);
          setDevices(sensorDevices);
          if (sensorDevices.length > 0) {
            setSelectedDeviceId(String(sensorDevices[0].id));
          }
        } else {
          setError(json.message || 'Failed to fetch devices list.');
        }
      } catch (err) {
        console.error('Failed to load devices:', err);
        setError('Failed to connect to the backend.');
      } finally {
        setLoading(false);
      }
    };
    fetchDevices();
  }, []);

  // Find currently selected device details
  const selectedDevice = useMemo(() => {
    return devices.find(d => String(d.id) === selectedDeviceId) || null;
  }, [devices, selectedDeviceId]);

  // 2. Fetch telemetry for selected device
  useEffect(() => {
    if (!selectedDeviceId || !selectedDevice) return;

    // Clear state when switching devices
    setTelemetry({});
    setLastUpdated(null);
    setTimeAgo('');

    // If device is offline, do not poll backend for telemetry
    const isOffline = (selectedDevice.status || '').toLowerCase() === 'offline';
    if (isOffline) return;

    const fetchTelemetryAndAlerts = async () => {
      try {
        // Fetch Telemetry
        const res = await fetch(`http://localhost:5000/api/sensors?deviceId=${selectedDeviceId}`);
        const json = await res.json();
        if (res.ok && json.success) {
          if (json.data.length > 0) {
            // Group by metric name and find the latest reading
            const latestReadings = {};
            let latestTime = null;

            json.data.forEach(row => {
              if (!latestReadings[row.sensor_name]) {
                latestReadings[row.sensor_name] = row.sensor_value;
                const rowTime = new Date(row.recorded_at);
                if (!latestTime || rowTime > latestTime) {
                  latestTime = rowTime;
                }
              }
            });

            setTelemetry(latestReadings);
            if (latestTime) {
              setLastUpdated(latestTime);
            }
          } else {
            setTelemetry({});
            setLastUpdated(null);
          }
        }

        // Fetch Alerts for current device
        const alertsRes = await fetch(`http://localhost:5000/api/alerts?device_id=${selectedDeviceId}`);
        const alertsJson = await alertsRes.json();
        if (alertsRes.ok && alertsJson.success) {
          const unresolved = alertsJson.data.filter(a => a.status !== 'Resolved');
          setActiveAlerts(unresolved);
        }
      } catch (err) {
        console.error('Failed to poll telemetry/alerts:', err);
      }
    };

    fetchTelemetryAndAlerts();
    const interval = setInterval(fetchTelemetryAndAlerts, 5000);
    return () => clearInterval(interval);
  }, [selectedDeviceId, selectedDevice]);

  // Update "time ago" string
  useEffect(() => {
    if (!lastUpdated) {
      setTimeAgo('');
      return;
    }

    const updateAgo = () => {
      const diffMs = new Date() - lastUpdated;
      const diffSecs = Math.max(0, Math.floor(diffMs / 1000));
      if (diffSecs < 5) {
        setTimeAgo('just now');
      } else {
        setTimeAgo(`${diffSecs} seconds ago`);
      }
    };

    updateAgo();
    const timer = setInterval(updateAgo, 1000);
    return () => clearInterval(timer);
  }, [lastUpdated]);

  // Helpers to resolve icons and units dynamically
  const getMetricMetadata = (name) => {
    const lowercase = name.toLowerCase();
    
    if (lowercase.includes('temperature') || lowercase === 'temp') {
      return { icon: Thermometer, unit: '°C', label: 'Temperature' };
    }
    if (lowercase.includes('humidity')) {
      return { icon: Droplets, unit: '%', label: 'Humidity' };
    }
    if (lowercase.includes('pressure')) {
      return { icon: Gauge, unit: 'hPa', label: 'Pressure' };
    }
    if (lowercase.includes('battery') || lowercase.includes('charge')) {
      return { icon: Battery, unit: '%', label: 'Battery Level' };
    }
    if (lowercase.includes('signal') || lowercase.includes('rssi')) {
      return { icon: Signal, unit: '%', label: 'Signal Strength' };
    }
    if (lowercase.includes('aqi') || lowercase.includes('air quality')) {
      return { icon: Activity, unit: '', label: 'AQI' };
    }
    if (lowercase.includes('pm2.5')) {
      return { icon: Activity, unit: ' µg/m³', label: 'PM2.5' };
    }
    if (lowercase.includes('pm10')) {
      return { icon: Activity, unit: ' µg/m³', label: 'PM10' };
    }
    if (lowercase.includes('water level')) {
      return { icon: Droplets, unit: '%', label: 'Water Level' };
    }
    if (lowercase.includes('volume')) {
      return { icon: Gauge, unit: ' L', label: 'Tank Volume' };
    }
    if (lowercase.includes('flow rate') || lowercase.includes('flow')) {
      return { icon: Activity, unit: ' L/min', label: 'Flow Rate' };
    }
    if (lowercase.includes('consumption')) {
      return { icon: Zap, unit: ' L', label: 'Total Consumption' };
    }
    if (lowercase.includes('motion status') || lowercase.includes('motion')) {
      return { icon: Eye, unit: '', label: 'Motion Status' };
    }
    if (lowercase.includes('motion count')) {
      return { icon: Eye, unit: '', label: 'Motion Count' };
    }
    if (lowercase.includes('last motion')) {
      return { icon: Compass, unit: '', label: 'Last Motion' };
    }
    if (lowercase.includes('light') || lowercase.includes('intensity') || lowercase.includes('lux')) {
      return { icon: Sun, unit: ' Lux', label: 'Light Intensity' };
    }
    if (lowercase.includes('smoke')) {
      return { icon: AlertTriangle, unit: ' ppm', label: 'Smoke Level' };
    }
    if (lowercase.includes('gas') || lowercase.includes('concentration')) {
      return { icon: AlertTriangle, unit: ' ppm', label: 'Gas Concentration' };
    }
    if (lowercase.includes('vibration')) {
      return { icon: Activity, unit: ' mm/s', label: 'Vibration Level' };
    }
    if (lowercase.includes('frequency')) {
      return { icon: Activity, unit: ' Hz', label: 'Frequency' };
    }
    if (lowercase.includes('health')) {
      return { icon: Heart, unit: '%', label: 'Equipment Health' };
    }
    if (lowercase.includes('soil moisture')) {
      return { icon: Droplets, unit: '%', label: 'Soil Moisture' };
    }
    if (lowercase.includes('soil temperature')) {
      return { icon: Thermometer, unit: '°C', label: 'Soil Temperature' };
    }
    if (lowercase.includes('voltage')) {
      return { icon: Zap, unit: ' V', label: 'Voltage' };
    }
    if (lowercase.includes('current')) {
      return { icon: Zap, unit: ' A', label: 'Current' };
    }
    if (lowercase.includes('power')) {
      return { icon: Zap, unit: ' W', label: 'Power Consumption' };
    }
    if (lowercase.includes('energy')) {
      return { icon: Zap, unit: ' kWh', label: 'Energy Used' };
    }
    if (lowercase.includes('latitude')) {
      return { icon: Compass, unit: '°', label: 'Latitude' };
    }
    if (lowercase.includes('longitude')) {
      return { icon: Compass, unit: '°', label: 'Longitude' };
    }
    if (lowercase.includes('speed')) {
      return { icon: Activity, unit: ' km/h', label: 'Speed' };
    }
    if (lowercase.includes('distance')) {
      return { icon: Compass, unit: ' km', label: 'Distance Today' };
    }
    if (lowercase.includes('status')) {
      return { icon: Radio, unit: '', label: 'Status' };
    }

    return { icon: Cpu, unit: '', label: name };
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-danger/10 border border-danger text-danger p-4 rounded-lg text-center font-medium">
        {error}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Selection & Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-card border border-border rounded-xl p-5">
        <div className="flex flex-col space-y-1 w-full sm:w-auto">
          <label className="text-xs font-semibold text-muted uppercase tracking-wider">Select Device</label>
          <select
            value={selectedDeviceId}
            onChange={(e) => setSelectedDeviceId(e.target.value)}
            className="bg-background border border-border rounded-md px-3 py-2 text-sm text-text focus:outline-none focus:border-primary cursor-pointer w-full sm:w-64"
          >
            {devices.map(d => (
              <option key={d.id} value={d.id}>
                {d.device_name} ({d.device_code})
              </option>
            ))}
            {devices.length === 0 && (
              <option value="">No sensor devices registered</option>
            )}
          </select>
        </div>

        {selectedDevice && (
          <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-sm">
            <div className="flex items-center space-x-2">
              <span className="text-muted">Type:</span>
              <span className="font-semibold text-text">{selectedDevice.device_type}</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="text-muted">Category:</span>
              <span className="font-semibold text-text bg-secondary/50 px-2 py-0.5 rounded text-xs">{selectedDevice.sensor_type}</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="text-muted">Status:</span>
              <StatusBadge status={selectedDevice.status} />
            </div>
          </div>
        )}
      </div>

      {/* Main Monitoring Section */}
      {selectedDevice ? (
        <>
          {(selectedDevice.status || '').toLowerCase() === 'offline' ? (
            <div className="bg-danger/10 border border-danger/30 text-danger p-6 rounded-xl text-center space-y-2">
              <AlertTriangle className="w-10 h-10 mx-auto text-danger animate-pulse" />
              <h3 className="text-lg font-bold">Device Offline</h3>
              <p className="text-sm opacity-90 max-w-md mx-auto">
                No telemetry available. Telemetry simulation is disabled while device status is Offline.
              </p>
            </div>
          ) : Object.keys(telemetry).length === 0 ? (
            <div className="bg-secondary/20 border border-border rounded-xl p-8 text-center space-y-2 text-muted">
              <Cpu className="w-10 h-10 mx-auto" />
              <h3 className="text-lg font-bold text-text">No telemetry available</h3>
              <p className="text-sm">
                Waiting for the device to transmit its initial data packets.
              </p>
            </div>
          ) : (
            <div className="space-y-6">
              {/* Poll Status Info & Active Alert Count */}
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 text-xs text-muted">
                <div className="flex items-center space-x-1.5">
                  <span className="w-2 h-2 rounded-full bg-success animate-ping"></span>
                  <span>Connected & Polling</span>
                </div>
                {activeAlerts.length > 0 && (
                  <div className="bg-danger/10 border border-danger/20 text-danger px-2.5 py-0.5 rounded-full font-semibold animate-pulse">
                    Active Incident Alerts: {activeAlerts.length}
                  </div>
                )}
                {lastUpdated && (
                  <div>
                    Last updated: <span className="font-medium text-text">{lastUpdated.toLocaleTimeString()}</span> ({timeAgo})
                  </div>
                )}
              </div>

              {/* Device-Level Incident Banner */}
              {activeAlerts.length > 0 && (
                <div className="bg-danger/10 border border-danger/30 text-danger p-4 rounded-xl flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <AlertTriangle className="w-5 h-5 text-danger animate-bounce" />
                    <span className="font-semibold text-sm">
                      Telemetry warning: device thresholds are being exceeded. Client notifications triggered.
                    </span>
                  </div>
                  <span className="text-xs bg-danger text-white px-2 py-0.5 rounded-full font-bold uppercase animate-pulse">
                    Anomaly Detected
                  </span>
                </div>
              )}

              {/* Dynamic Metrics Cards Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {Object.entries(telemetry).map(([metricName, metricValue]) => {
                  const meta = getMetricMetadata(metricName);
                  const IconComponent = meta.icon;

                  const metricAlert = activeAlerts.find(a => a.metric_name === metricName);
                  const hasAlert = !!metricAlert;

                  // Detect alert status style if status metrics represent alerts
                  const isWarning = metricName.toLowerCase() === 'status' && metricValue.toLowerCase().includes('warning');
                  const isNormal = metricName.toLowerCase() === 'status' && metricValue.toLowerCase() === 'normal';

                  return (
                    <div 
                      key={metricName} 
                      className={`bg-card border rounded-xl p-6 relative overflow-hidden group hover:border-primary/30 transition-all ${
                        hasAlert ? 'border-danger/40 ring-1 ring-danger/20' : 'border-border'
                      }`}
                    >
                      <div className="absolute -right-6 -top-6 text-primary/5 group-hover:text-primary/10 transition-colors">
                        <IconComponent className="w-28 h-28" />
                      </div>

                      <div className="relative z-10 flex flex-col h-full justify-between">
                        <div>
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center space-x-2 text-primary">
                              <IconComponent className="w-5 h-5" />
                              <span className="font-semibold text-sm">{meta.label}</span>
                            </div>
                            
                            {/* Alert and Severity Badges */}
                            <div className="flex items-center space-x-1.5">
                              {hasAlert && (
                                <span className="bg-danger text-white text-[9px] px-1.5 py-0.5 rounded font-bold uppercase animate-pulse">
                                  🚨 Alert
                                </span>
                              )}
                              <span className={`text-[9px] px-1.5 py-0.5 rounded font-bold uppercase ${
                                hasAlert && metricAlert.severity === 'Critical' ? 'bg-danger/20 text-danger border border-danger/30' :
                                hasAlert && metricAlert.severity === 'High' ? 'bg-orange-500/20 text-orange-500 border border-orange-500/30' :
                                hasAlert && metricAlert.severity === 'Medium' ? 'bg-warning/20 text-warning border border-warning/30' :
                                hasAlert && metricAlert.severity === 'Low' ? 'bg-primary/20 text-primary border border-primary/30' :
                                'bg-success/20 text-success border border-success/30'
                              }`}>
                                {hasAlert ? metricAlert.severity : 'Normal'}
                              </span>
                            </div>
                          </div>

                          <div className="flex items-baseline space-x-1.5">
                            <span className="text-3xl font-bold text-text truncate max-w-full">
                              {metricValue}
                            </span>
                            {meta.unit && (
                              <span className="text-sm text-muted font-medium">{meta.unit}</span>
                            )}
                          </div>

                          {hasAlert && (
                            <div className="text-[10px] text-danger mt-2 font-medium flex items-center space-x-1">
                              <span className="w-1.5 h-1.5 rounded-full bg-danger animate-ping mr-1"></span>
                              <span>Exceeded threshold: {metricAlert.threshold_value}{meta.unit}</span>
                            </div>
                          )}
                        </div>

                        {/* Status badges for dynamic status variables */}
                        {metricName.toLowerCase() === 'status' && (
                          <div className={`mt-4 flex items-center text-xs w-fit px-2.5 py-1 rounded-md font-medium ${
                            isWarning ? 'text-danger bg-danger/10 border border-danger/20' :
                            isNormal ? 'text-success bg-success/10 border border-success/20' :
                            'text-text bg-secondary/80 border border-border'
                          }`}>
                            <span className={`w-1.5 h-1.5 rounded-full mr-1.5 ${
                              isWarning ? 'bg-danger animate-pulse' :
                              isNormal ? 'bg-success' : 'bg-muted'
                            }`}></span>
                            {metricValue}
                          </div>
                        )}

                        {/* General alerts inside custom values */}
                        {metricName.toLowerCase() === 'alert status' && (
                          <div className={`mt-4 flex items-center text-xs w-fit px-2.5 py-1 rounded-md font-medium ${
                            metricValue.toLowerCase() === 'warning' ? 'text-danger bg-danger/10 border border-danger/20 animate-pulse' :
                            'text-success bg-success/10 border border-success/20'
                          }`}>
                            <span className={`w-1.5 h-1.5 rounded-full mr-1.5 ${
                              metricValue.toLowerCase() === 'warning' ? 'bg-danger animate-pulse' : 'bg-success'
                            }`}></span>
                            {metricValue}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </>
      ) : (
        <div className="bg-card border border-border rounded-xl p-12 text-center text-muted">
          Please select or register a sensor device to monitor its telemetry.
        </div>
      )}
    </div>
  );
}
